---
author: <% await tp.system.prompt("Auteur (Nom, Prénom)") %>
title: <% await tp.system.prompt("Titre") %>
year: <% await tp.system.prompt("Année de parution") %>
citekey: '@<% await tp.system.prompt("Clef de citation (sans @") %>'
itemtype: <% await tp.system.prompt("Type de document") %>
statut: <% await tp.system.suggester(["Terminé", "En cours"], ["Terminé", "En cours"]) %>
date-lecture: <% tp.file.creation_date("YYYY-MM-DD") %>
tags:
  - "#littérature"
note: 
connexe: 
contribution: <% await tp.system.prompt("Contribution") %>
---


> [!Abstract]
> **Abstract**::



%%------------------

# READ ME

Template pour *fiche de lecture* qui suit les conventions de celle fonctionnant avec Zotero mais qui peut être utilisé en tant que telle. Peut être utile si vous avez des documents qui ne sont pas dans Zotero. 


--------------------%