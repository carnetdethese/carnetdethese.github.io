---
aliases: []
---

**Date**:: <% tp.file.creation_date("YYYY-MM-DD") %>


## Ref. 



%%------------------

# READ ME

Template pour les notes type *Zettelkasten*. Assez rudimentaire, qui vous pouvez agrémenter à votre convenance.


--------------------%