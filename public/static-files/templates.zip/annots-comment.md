---
author: "{% for creator in creators %}{{creator.lastName}}, {{creator.firstName}} - {% endfor %}"
title: "{{title}}"
year: '{{date | format("YYYY")}}'
citekey: "@{{citationKey}}"
itemtype: "{{itemType}}"
statut: <% await tp.system.suggester(["Terminé", "En cours"], ["Terminé", "En cours"]) %>
date-lecture: <% tp.file.creation_date("YYYY-MM-DD") %>
tags:
  - "#littérature"
note: 
connexe: "{% if relations %}{% for connexe in relations %}[[{{connexe.citationKey}}]] - {% endfor%}{% endif %}"
contribution: <% await tp.system.prompt("Contribution") %>
---

%%--------------------------------------
# READ ME

## TEMPLATE : FICHES DE LECTURE ZOTERO.

**Plugins utilisés** : 
- *Templater* (module communautaire)
	- Pensez à configurer ce module avant l'utilisation du template ;
	- Désactivez le module *Template* d'origine !
	- Consultez la [documentation](https://silentvoid13.github.io/Templater/introduction.html) pour comprendre les éléments présents en en-tête. L'utilisation des fonctions du module `system` est très puissante et vous permet d'automatiser beaucoup de choses dans vos notes !
- *Zotero Integration* (idem) - v. la [documentation](https://github.com/mgmeyers/obsidian-zotero-integration/blob/main/docs/README.md)

**Utilisation** :
- Placer ce document dans le coffre Obsidian (ex. "Templates/annotations.md") ;
- Installer les plugins nécessaires ;
- Dans *Zotero Integration*, ajouter un *Format* (onglet *Import format*) ;
- Entrer les informations en fonction de vos besoins ;
- Dans l'encart "Template", entrer le nom du fichier et son chemin (ex. "Templates/annotations.md").

Le template est commenté pour une meilleure compréhension ; les commentaire sont surlignés, mais n'apparaîtront pas dans le produit final. Pour toute question, n'hésitez pas à me contacter [par mail](mailto:alexandre.mimms@u-paris2.fr).

-----------------------------------------------%%



{% if desktopURI or callNumber or libraryCatalog or extra %} %% ==Si le document contient une côte ou un numéro de bibliothèque (pour identification physique).== %%
> [!info] %% ==Création d'un *callout*. Dedans, on va y insérer une information différente en fonction de ce qu'on a dans l'entrée Zotero.== %%
{% if desktopURI %}> - [{{citationKey}} - Lien Zotero]({{desktopURI}}) {% endif%}
{% if libraryCatalog %}> - {{libraryCatalog}} {% if callNumber %} - {{callNumber}} {% endif %} {% endif %}
{% if extra %}> - {{extra}} {%- endif -%}
{% endif %}

{%- if abstractNote %} %% ==Si on a un abstract, on insère un *callout* qui va contenir l'information.== %%

> [!abstract]
> {{abstractNote}}
{%- endif -%} %% ==Fin de la boucle *if*.== %%

{% if annotations.length %} %% ==Condition pour vérifier que nous avons des annotations (highlights ou commentaires). La condition regarde si le dictionnaire *annotations* contient des entrées (*a une certaine longueur différente de 0 -> .length*).== %%

## Annotations %% ==On insère un titre== %%

%%---------------------- 

La suite fait un peu peur, mais prenez le temps de lire et comprendre, ce n'est pas si difficile. Il s'agit d'une suite de conditions qui va attribuer à chaque couleur présente dans les données du PDF renvoyé par Zotero un emoji différent en fonction d'un code déterminé à l'avance. Si vous n'en avez pas besoin, vous pouvez tout à fait supprimer les éléments.

Structure :
- *Si* le titre de la publication est différent de (!=) Law Quarterly Review 
	- *Pour* (for) l'annotation *présente* (in) dans le dictionnaire *annotations* (notez le *s*)
		- *Si* la couleur est différente (!=) de `#5fb236` et si la couleur est différente de `#ffa800` et si le commentaire est différent de `ref.` et si la couleur est différente de `#aaaaa`
			- *Si* l'annotation contient un texte annoté
				- Insérer `> [!cite] p. **{{annotation.pageLabel}}**` 
					- *Si* la couleur est jaune -> 💡
					- *Si* la couleur est bleu  -> 🔥
					- *Si* la couleur est rouge -> 🤔
					- *Si* la couleur est magenta -> 👀 
				- Insérer `> « {{annotation.annotatedText}} »`
				- *Si* l'annotation contient un commentaire 
					- Insérer le commentaire et la date.
			- *Si* l'annotation ne contient pas de texte annoté mais contient tout de même un commentaire
				- Insérer `p. **{{annotation.pageLabel}}** -` et le commentaire (permet d'avoir un format différent du callout que je trouve confus pour ce genre de commentaires)
		- *Si* l'annotation contient un commentaire égal à 
			- ".h1" -> insérer un titre de niv. 1 
			- ".h2" -> insérer un titre de niv. 2
			- ".h3" -> insérer un titre de niv. 3 
			- ".h4" -> insérer un titre de niv. 4
--------------------%%


{% if publicationTitle != "Law Quarterly Review" %}{% for annotation in annotations %}{% if annotation.color != "#5fb236" and annotation.color != "#ffa800" and annotation.comment != "ref." and annotation.color != "#aaaaaa" %}{% if annotation.annotatedText %}> [!cite] p. **{{annotation.pageLabel}}** {% if annotation.colorCategory == "Yellow" %}💡{% elif annotation.colorCategory == "Blue" %} 🔥 {% elif annotation.colorCategory == "Red" %} 🤔 {% elif annotation.colorCategory == "Magenta" %} 👀 {% endif %}
> « {{annotation.annotatedText}} »{% if annotation.comment %}
> - ✏️ {{annotation.comment}} ({{annotation.date | format("YYYY-MM-DD#h:mm a")}}){% endif %}{% endif %}{% endif %}
{% if not annotation.annotatedText and annotation.comment %} p. **{{annotation.pageLabel}}** - {{annotation.comment}} {% endif %}
{% if annotation.comment == ".h1" %}### {{annotation.annotatedText}}{% endif %}{% if annotation.comment == ".h2" %}#### {{annotation.annotatedText}}{% endif %}{% if annotation.comment == ".h3" %}##### {{annotation.annotatedText}}{% endif %}{% if annotation.comment == ".h4" %}###### {{annotation.annotatedText}}{% endif %}

{% endfor %}{% endif %}{% endif %}

{% if markdownNotes %} %% ==S'il existe des notes dans l'entrée Zotero qui ne sont attachés à aucun PDF== %%
### Autres notes %% insérer un titre %%
{{markdownNotes}}
{% endif %}

%% ==La boucle suivante récupère ensuite les annotations dont la couleur est verte (choix personnel) qui sont des références bibliographiques que je souhaite associer à la lecture. Me permet d'éviter d'avoir à récopier les références sans les insérer dans Zotero immédiatement.== %% 

## Bibliographie 

{% for a in annotations %}{% if a.color == "#5fb236" or a.color == "#ffa800" or annotation.comment == "ref." %}- {{a.annotatedText}}{% if a.comment %} - *{{a.comment}}* {% endif %}
{% endif %}{% endfor %}