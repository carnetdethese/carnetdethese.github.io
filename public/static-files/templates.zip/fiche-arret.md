---
date: <% await tp.system.prompt("Date") %>
juridiction: <% await tp.system.suggester(["Conseil constitutionnel", "Conseil d'Etat", "CJUE", "CEDH", "Cour de cassation", "TA", "CAA"], ["Conseil constitutionnel", "Conseil d'Etat", "CJUE", "CEDH", "Cour de cassation", "TA", "CAA"]) %>
formation: 
nom: <% await tp.system.prompt("Nom de la décision") %>
apport: 
numero: <% await tp.system.prompt("Numéro de la décision") %>
citation: 
lien: <% await tp.system.prompt("Lien web") %>
tags:
  - fiche-arret
---

%%--------------------------------

# READ ME

L'intérêt de ce template se trouve dans l'en-tête. J'ai fait en sorte qu'à chaque appel du template, le module me demande d'entrer la date de l'arrêt (format YYYY-MM-DD), la juridiction (vous pouvez adapter en fonction de vos besoins), le nom, le numéro, et le lien web de la décision. Vous pouvez aussi faire en sorte qu'il vous demande d'y ajouter l'apport en ajoutant :
`await tp.system.prompt("Apport")` (entre les chevrons et le symbole pourcentage).

Pour la citation, je n'ai pas encore trouvé de manière de l'insérer autrement que : 
- Par un copier coller de Zotero 
- Par l'utilisation d'un autre template, que j'ai enregistré dans des fichiers spécifiques pour le format que j'attends. V. plus bas.


ATTENTION : la partie qui suit DOIT être retiré avant exécution pour éviter des erreurs inattendues. Ce n'est là qu'à des fins de documentation.


citation-conseil-etat : 
```js
<%* moment.locale('fr') ; let dateDecision = moment(tp.frontmatter["date"]).format("D MMMM YYYY") %> CE, <% dateDecision %>, n° <% tp.frontmatter["numero"] %>, *<% tp.frontmatter["nom"] %>
```


citation-conseil-constit :
```js
<%* moment.locale('fr') ; let dateDecision = moment(tp.frontmatter["date"]).format("D MMMM YYYY") %> Cons. constit., n° <% tp.frontmatter["numero"] %>, <% dateDecision %>, *<% tp.frontmatter["nom"] %>*
```


Tout ce qui se trouve en dessous peut être modifié à votre convenance.
--------------------------------%%

## Fiche et commentaire
### Fiche d'arrêt

**Faits** -

**Procédure** -

**Moyens** - 

**Question de droit** -

**Solution** - 

### Commentaire

## Décision