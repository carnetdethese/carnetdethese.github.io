%%---------------
# READ ME

J'utilise ce template pour m'organiser dans les enseignements. C'est un *dashboard*, une sorte de lieu où je retrouve toutes les informations relatives aux travaux dirigés. 

En général, ces tableaux de bords ont tendance à évoluer au cours des semestres avec les notes des réunions, les éléments importants etc. Très utile pour éviter de perdre des choses importantes. 

-------------------%%




Last modified date: <%+ tp.file.last_modified_date() %>

> [!SUMMARY] En bref
> **Salle**:: 
> 
> **Horaires**:: 
> 
> **Contact**:: 
> 
> **Support de cours**::
> 
> **Barèmes**::
> 
> **Fiche de présence**:: 
> 
> **Délégué**:: 

> [!IMPORTANT]+ DATES IMPORTANTES
> Réunion de rentrée :

### Fiches et calendrier

```dataview
TABLE 
	date,
	seance,
	theme,
	statut,
	devoir-maison
FROM "04 Projets/04-01 Travaux Dirigés/ . . . /Séances"
SORT date ASC
```

### Notes

